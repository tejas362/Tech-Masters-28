import pygame
import sys

# Initialize pygame
pygame.init()

# Set up display
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Python Quiz - Level 1")

# Load background image
background = pygame.image.load("level1bg.jpg")
background = pygame.transform.scale(background, (WIDTH, HEIGHT))

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# Load Custom Font (Ensure the .ttf file is in the same directory as level1.py)
# If you don't have a custom font, you can use a system font like "Comic Sans MS"
try:
    stylish_font = pygame.font.Font("Kanit-Bold.ttf", 25)  # Custom font
except FileNotFoundError:
    stylish_font = pygame.font.SysFont("Comic Sans MS", 36)  # Fallback to Comic Sans MS

def draw_text(text, y, color=BLACK):
    render = stylish_font.render(text, True, color)
    text_rect = render.get_rect(center=(WIDTH // 2, y))
    screen.blit(render, text_rect)

def introduction():
    screen.blit(background, (0, 0))
    draw_text("Welcome to Python Quiz - Level 1", 150)
    draw_text("In this quiz, you'll learn some basic Python concepts!", 220)
    draw_text("Topics include printing, variables, data types, loops, and functions.", 290)
    draw_text("Example: print('Hello, World!')", 360)
    draw_text("Press any key to start the quiz.", 430)
    pygame.display.flip()
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                waiting = False

def quiz():
    questions = [
        ("What is the correct way to print in Python?", [
            "A) echo 'Hello'",
            "B) print('Hello')",
            "C) printf('Hello')",
            "D) System.out.println('Hello')"], "B"),
        ("Which symbol is used for comments in Python?", [
            "A) //", "B) /* */", "C) #", "D) --"], "C"),
        ("What is the correct way to declare a variable in Python?", [
            "A) var x = 5", "B) x = 5", "C) int x = 5", "D) let x = 5"], "B"),
        ("How do you take user input in Python?", [
            "A) input()", "B) get_input()", "C) scan()", "D) read()"], "A"),
        ("Which data type is used to store a sequence of characters?", [
            "A) int", "B) float", "C) str", "D) bool"], "C"),
        ("Which loop is used to iterate over a range of numbers?", [
            "A) for", "B) while", "C) repeat", "D) loop"], "A"),
        ("What keyword is used to define a function in Python?", [
            "A) function", "B) def", "C) define", "D) func"], "B"),
        ("How do you check if two values are equal in Python?", [
            "A) =", "B) ==", "C) ===", "D) equals"], "B")
    ]
    
    for question, options, correct in questions:
        screen.blit(background, (0, 0))
        draw_text(question, 100)
        for i, option in enumerate(options):
            draw_text(option, 200 + (i * 50))
        draw_text("Press A, B, C, or D to answer", 500)
        pygame.display.flip()
        
        answering = True
        while answering:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.unicode.upper() == correct:
                        screen.blit(background, (0, 0))
                        draw_text("Correct!", 300, GREEN)
                    else:
                        screen.blit(background, (0, 0))
                        draw_text(f"Wrong! The correct answer is {correct}.", 300, RED)
                    pygame.display.flip()
                    pygame.time.delay(1000)
                    answering = False

def start_level1():
    introduction()
    quiz()

# Ensure it only runs when called explicitly
if __name__ == "__main__":
    start_level1()
