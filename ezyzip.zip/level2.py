import pygame
import sys
import time
import random

def start_level2(screen):
    pygame.display.set_caption("Level 2")

    # Colors
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    GREEN = (50, 205, 50)
    RED = (255, 69, 0)
    GRAY = (169, 169, 169)

    # Fonts
    font = pygame.font.Font(None, 48)
    button_font = pygame.font.Font(None, 36)

    def draw_button(text, x, y, width, height, color, hover_color):
        """Draw a button and return its rect."""
        mouse_x, mouse_y = pygame.mouse.get_pos()
        button_rect = pygame.Rect(x, y, width, height)
        if button_rect.collidepoint(mouse_x, mouse_y):
            pygame.draw.rect(screen, hover_color, button_rect, border_radius=15)
        else:
            pygame.draw.rect(screen, color, button_rect, border_radius=15)
        
        text_surf = button_font.render(text, True, WHITE)
        text_rect = text_surf.get_rect(center=(x + width // 2, y + height // 2))
        screen.blit(text_surf, text_rect)
        return button_rect

    # Welcome Screen
    screen.fill(WHITE)
    draw_text(screen, "Welcome to Level 2!", 400, 250, 48, BLACK)
    pygame.display.update()
    time.sleep(2)

    # List of Questions on Loops & Conditionals
    questions = [
        {"question": "Which loop runs a fixed number of times?", "options": ["for loop", "while loop", "do-while loop"], "answer": 0},
        {"question": "What will if 5 > 3: do?", "options": ["Execute code", "Throw error", "Nothing"], "answer": 0},
        {"question": "What does while True: do?", "options": ["Infinite loop", "Runs once", "Throws error"], "answer": 0},
        {"question": "How do you stop a loop?", "options": ["break", "continue", "stop"], "answer": 0},
        {"question": "What does for i in range(3): print(i) output?", "options": ["0 1 2", "1 2 3", "0 1 2 3"], "answer": 0},
        {"question": "What does else do in a loop?", "options": ["Runs if loop finishes", "Runs only once", "Throws error"], "answer": 0}
    ]

    question_index = 0

    while question_index < len(questions):
        screen.fill(WHITE)
        current_question = questions[question_index]

        # Shuffle answer options
        options = current_question["options"]
        random.shuffle(options)
        correct_option = current_question["options"][current_question["answer"]]
        correct_index = options.index(correct_option)

        draw_text(screen, current_question["question"], 400, 150, 40, BLACK)

        buttons = []
        for i, option in enumerate(options):
            button = draw_button(option, 300, 250 + (i * 70), 200, 50, GREEN, (34, 139, 34))
            buttons.append((button, i))

        pygame.display.update()

        answered = False
        while not answered:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    for button, idx in buttons:
                        if button.collidepoint(event.pos):
                            if idx == correct_index:
                                feedback_text = "✅ Correct Answer!"
                                feedback_color = GREEN
                                question_index += 1  # Move to next question
                                answered = True
                            else:
                                feedback_text = "❌ Wrong Answer! Try Again."
                                feedback_color = RED
                            
                            # Show feedback message
                            screen.fill(WHITE)
                            draw_text(screen, current_question["question"], 400, 150, 40, BLACK)
                            for button, i in buttons:
                                draw_button(options[i], 300, 250 + (i * 70), 200, 50, GREEN, (34, 139, 34))
                            draw_text(screen, feedback_text, 400, 500, 36, feedback_color)
                            pygame.display.update()
                            time.sleep(1)  # Pause before moving forward

    # Completion Screen
    screen.fill(WHITE)
    draw_text(screen, "Level 2 Completed!", 400, 250, 48, GREEN)
    pygame.display.update()
    time.sleep(2)
    return

# Function to display text
def draw_text(screen, text, x, y, font_size, color):
    font = pygame.font.Font(None, font_size)
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(center=(x, y))
    screen.blit(text_surface, text_rect)