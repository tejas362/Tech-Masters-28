import pygame
import sys
from level1 import start_level1  # Import Level 1 function
from level2 import start_level2  # Import Level 2 function

# Initialize Pygame
pygame.init()

# Set up the game window
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Coding Game for Kids")

# Define Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BRIGHT_GREEN = (50, 205, 50)
BRIGHT_RED = (255, 69, 0)
DARK_GRAY = (105, 105, 105)

# Fonts
font = pygame.font.Font("Kanit-Bold.ttf", 48)
button_font = pygame.font.Font("Kanit-Bold.ttf", 24)

# Load background images
background_image = pygame.image.load("background_image.jpg")
background_image = pygame.transform.scale(background_image, (800, 600))

background2_image = pygame.image.load("background2.jpg")
background2_image = pygame.transform.scale(background2_image, (800, 600))

# Function to create a rounded button with hover effect
def draw_rounded_button(text, x, y, width, height, color, hover_color, radius=20):
    mouse_x, mouse_y = pygame.mouse.get_pos()
    button_rect = pygame.Rect(x, y, width, height)
    if button_rect.collidepoint(mouse_x, mouse_y):
        pygame.draw.rect(screen, hover_color, button_rect, border_radius=radius)
    else:
        pygame.draw.rect(screen, color, button_rect, border_radius=radius)

    text_surf = button_font.render(text, True, WHITE)
    text_rect = text_surf.get_rect(center=(x + width // 2, y + height // 2))
    screen.blit(text_surf, text_rect)
    return button_rect

# Function to display text
def draw_text(text, x, y, font_size, color):
    font = pygame.font.Font("Kanit-Bold.ttf", font_size)
    text_surf = font.render(text, True, color)
    text_rect = text_surf.get_rect(center=(x, y))
    screen.blit(text_surf, text_rect)

# Function to start a level dynamically
def start_level(level):
    if level == 1:
        start_level1()
    elif level == 2:
        start_level2(screen)  # Ensure screen is passed correctly
    else:
        print("Coming Soon!")

# Level selection page
def level_selection_page():
    game_running = True
    while game_running:
        screen.fill(WHITE)
        screen.blit(background2_image, (0, 0))
        draw_text("Select a Level", 400, 50, 60, BLACK)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = event.pos
                for level in range(1, 11):
                    button_x = 150 + (level - 1) % 3 * 160
                    button_y = 150 + (level - 1) // 3 * 100
                    if pygame.Rect(button_x, button_y, 150, 60).collidepoint(mouse_x, mouse_y):
                        start_level(level)
                        game_running = False

        for level in range(1, 11):
            button_x = 150 + (level - 1) % 3 * 160
            button_y = 150 + (level - 1) // 3 * 100
            draw_rounded_button(f"Level {level}", button_x, button_y, 150, 60, BLACK, DARK_GRAY, radius=25)

        pygame.display.update()

# Main Game Loop
def game_loop():
    while True:
        screen.fill(WHITE)
        screen.blit(background_image, (0, 0))
        draw_text("GAME BEGINS... ALL THE BEST!!", 400, 150, 48, BLACK)
        draw_text("LOADING...", 400, 500, 40, BLACK)
        start_button = draw_rounded_button("Start Game", 300, 250, 200, 50, BRIGHT_GREEN, (34, 139, 34), radius=30)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if start_button.collidepoint(event.pos):
                    level_selection_page()

        pygame.display.update()

# Start the game
game_loop()