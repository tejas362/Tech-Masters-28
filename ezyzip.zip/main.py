import pygame
import sys

# Initialize Pygame
pygame.init()

# Set up the game window
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Coding Game for Kids")

# Define Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BRIGHT_GREEN = (50, 205, 50)
BRIGHT_RED = (255, 69, 0)
BRIGHT_BLUE = (30, 144, 255)
DARK_NAVY = (10, 10, 50)
VIBRANT_PINK = (255, 105, 180)
VIBRANT_PURPLE = (148, 0, 211)
SOFT_ORANGE = (255, 165, 0)
SOFT_BLUE = (70, 130, 180)
BRIGHT_YELLOW = (255, 223, 0)

# Fonts (Bold and Stylish)
font = pygame.font.SysFont("Arial", 48, bold=True)  # Increased font size for better visibility
large_font = pygame.font.SysFont("Arial", 70, bold=True)  # Larger Bold and Stylish font
small_font = pygame.font.SysFont("Arial", 36, bold=True)  # Smaller font for the task description
button_font = pygame.font.SysFont("Arial", 24, bold=True)  # Smaller font for button text

# Load background images
background_image = pygame.image.load("background_image.jpg")
background_image = pygame.transform.scale(background_image, (800, 600))

background2_image = pygame.image.load("background2.jpg")
background2_image = pygame.transform.scale(background2_image, (800, 600))

# Function to create a rounded button (with hover effect)
def draw_rounded_button(text, x, y, width, height, color, hover_color, radius=20):
    mouse_x, mouse_y = pygame.mouse.get_pos()
    button_rect = pygame.Rect(x, y, width, height)
    if button_rect.collidepoint(mouse_x, mouse_y):
        pygame.draw.rect(screen, hover_color, button_rect, border_radius=radius)
    else:
        pygame.draw.rect(screen, color, button_rect, border_radius=radius)

    # Dynamically adjust font size to fit text inside the button
    text_surf = button_font.render(text, True, WHITE)
    text_rect = text_surf.get_rect(center=(x + width // 2, y + height // 2))
    screen.blit(text_surf, text_rect)

# Function to display text with a shadow effect
def draw_text(text, x, y, font_size, color):
    shadow_offset = 2
    font = pygame.font.SysFont("Arial", font_size, bold=True)  # Bold font
    text_surf = font.render(text, True, (0, 0, 0))
    text_rect = text_surf.get_rect(center=(x + shadow_offset, y + shadow_offset))
    screen.blit(text_surf, text_rect)

    text_surf = font.render(text, True, color)
    text_rect = text_surf.get_rect(center=(x, y))
    screen.blit(text_surf, text_rect)

# Function to display the level selection page
def level_selection_page():
    game_running = True
    while game_running:
        screen.fill(WHITE)
        # Display background2 image
        screen.blit(background2_image, (0, 0))

        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = event.pos
                for level in range(1, 11):  # 10 levels
                    # Horizontal positions for each level button
                    button_x = 150 + (level - 1) % 3 * 160  # 3 buttons per row, spacing 160px
                    button_y = 150 + (level - 1) // 3 * 100  # Move to the next row after 3 buttons
                    if button_x <= mouse_x <= button_x + 150 and button_y <= mouse_y <= button_y + 60:
                        print(f"Level {level} selected")  # You can replace this with starting the corresponding level
                        game_running = False  # Exit the level selection after selecting a level

        # Display Title and Instructions
        draw_text("Select a Level", 400, 50, 60, BLACK)

        # Display buttons for levels 1-10 (3 buttons per row)
        for level in range(1, 11):
            # Horizontal positions for each level button
            button_x = 150 + (level - 1) % 3 * 160  # 3 buttons per row, spacing 160px
            button_y = 150 + (level - 1) // 3 * 100  # Move to the next row after 3 buttons
            draw_rounded_button(f"Level {level}", button_x, button_y, 150, 60, BLACK, (105, 105, 105), radius=25)

        # Update the display
        pygame.display.update()

# Main Game Loop
def game_loop():
    game_running = True
    task_active = False
    task_complete = False

    while game_running:
        # Fill the screen with white color and display the background image
        screen.fill(WHITE)
        screen.blit(background_image, (0, 0))

        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = event.pos
                if 300 <= mouse_x <= 500 and 250 <= mouse_y <= 300 and not task_active:
                    task_active = True
                elif 300 <= mouse_x <= 500 and 250 <= mouse_y <= 300 and task_active and not task_complete:
                    task_complete = True
                elif 300 <= mouse_x <= 550 and 500 <= mouse_y <= 550 and task_complete:
                    task_active = False
                    task_complete = False
                elif 300 <= mouse_x <= 500 and 250 <= mouse_y <= 300 and task_complete:  # Direct transition to level selection
                    level_selection_page()  # Go to level selection screen

        # Display Start button
        if not task_active:
            draw_rounded_button("Start Game", 300, 250, 200, 50, BRIGHT_GREEN, (34, 139, 34), radius=30)
            draw_text("GAME BEGINS......ALL THE BEST!!", 400, 150, 48, BLACK)  # Larger font and black color
            draw_text("LOADING........", 400, 500, 40, BLACK)  # Larger font and black color
        else:
            # Task prompts with smaller font for the task description
            draw_text("Solve the puzzle by clicking the button below!", 400, 100, 36, BLACK)  # Smaller font and black color
            draw_rounded_button("ENTER", 300, 250, 200, 50, BRIGHT_RED, (178, 34, 34), radius=30)

            if task_complete:
                # Directly go to the level selection screen after task completion
                level_selection_page()  # Go directly to the level selection screen

        # Update the display
        pygame.display.update()

# Start the game loop
game_loop()